# CS2_External
CS2 external cheat.


Analysis and implementation of CS2 external silent aimbot 

EN -> [SilentAimbot - en](https://github.com/TKazer/CS2-External-Silent-AimBot)

CN -> [SilentAimbot - cn](https://bbs.kanxue.com/thread-282616.htm)

## ImGui library -> [OS-ImGui](https://github.com/TKazer/OS-ImGui)

## Derivative projects
1. AimStar -> [AimStar](https://github.com/CowNowK/AimStar) (By CowNow.)
2. Aeonix -> [Aeonix](https://github.com/Fr0go1/Aeonix-Cs2) (By Fr0go1.)

## NOTICE

This source just used to study how to code a simple CS2 external hack systematically.

这个源码仅供学习如何系统的写一套CS2外部辅助程序。

The offsets will not be updated in the future, please update it by self.

后续偏移数据将不在提供更新，请自行更新。

<img src="https://github.com/TKazer/CS2_External/blob/master/Image2.png" width="1200" />

## Functions

> 1. BoneESP
>
> 2. BoxESP
>
> 3. AimBot (With rcs)
>
> 4. EyeLine
>
> 5. Auto update offsets
>
> 6. weaponESP
>
> 7. Radar
>
> 8. TriggerBot
>
> 9. HeadShoot Line
>
> 10. Fov Line
>
> 11. Visibility Check
>
> 12. OBS Bypass
>
> 13. Bhop
